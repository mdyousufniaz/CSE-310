// this is a file with syntax error

int i,j, a,b,c;
int main(){
	int k,ll,m,n,o,p;
    
    /*
    
    this is
    a
    multi-line
    comment
    just before
    the syntax error
    */

	int;

	return 0;
}

