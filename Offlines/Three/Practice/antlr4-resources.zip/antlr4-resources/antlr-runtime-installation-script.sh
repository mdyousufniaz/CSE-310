git clone https://github.com/antlr/antlr4.git
cd antlr4
cd runtime/Cpp
mkdir build && cd build
cmake ..
make
sudo make install